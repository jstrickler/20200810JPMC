from shutil import make_archive
make_archive('some_data', 'zip', 'DATA')
